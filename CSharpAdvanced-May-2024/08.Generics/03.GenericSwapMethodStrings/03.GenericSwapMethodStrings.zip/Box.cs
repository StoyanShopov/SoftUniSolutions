﻿namespace _03.GenericSwapMethodStrings
{ 
    public class Box<T>
    {
        public Box()
            => this.Items = new List<T>();

        public List<T> Items { get; set; }

        public void Swap(int firstIndex, int secondIndex)
        {
            //T tempValue = this.Items[firstIndex];
            //this.Items[firstIndex] = this.Items[secondIndex];
            //this.Items[secondIndex] = tempValue;

            (this.Items[secondIndex], this.Items[firstIndex]) 
                = (this.Items[firstIndex], this.Items[secondIndex]);
        }

        public override string ToString()
            => string.Join(
                Environment.NewLine,
                this.Items.Select(item => $"{typeof(T)}: {item}"));
    }
}
